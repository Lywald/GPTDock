﻿using OpenAI_API;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GPTDock
{
    /// <summary>
    /// Interaction logic for OverlayWindow.xaml
    /// </summary>
    public partial class OverlayWindow : Window
    {
        public OverlayWindow(string txt)
        {
            InitializeComponent();
            this.Topmost = true; // Makes the window always on top

            this.WindowStyle = WindowStyle.SingleBorderWindow; // No borders etc.
            this.AllowsTransparency = false; // Allows the window to be transparent
            this.Background = Brushes.White; // Transparent background
            this.MouseLeftButtonDown += (s, e) => this.DragMove(); // Allow the window to be moved by dragging
            this.KeyDown += (s, e) => ex(e);
            //this.Width = 380;
            //this.Height = 500;
            this.Padding = new Thickness(12);
            var ds = new DropShadowEffect();
            ds.BlurRadius = 2.22;
            ds.ShadowDepth = 1;

            // You could add more UI elements here or draw on the window
            /*TextBlock textBlockz = new TextBlock
            {
                Text = txt,
                Foreground = Brushes.White,
                FontSize = 22,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                TextWrapping = TextWrapping.Wrap,
                Effect = ds
            };*/

            this.textBlock.Text = txt;
            this.textBlock.Foreground = Brushes.Black;
            this.textBlock.FontSize = 22;
            this.textBlock.HorizontalAlignment = HorizontalAlignment.Center;
            this.textBlock.VerticalAlignment = VerticalAlignment.Center;
            this.textBlock.TextWrapping = TextWrapping.Wrap;
            this.textBlock.Focusable = true;
            this.WindowStartupLocation = WindowStartupLocation.Manual;
            this.Top = 500;
            this.Left = 500;
            //this.textBlock.Effect = ds;
            //this.Content = textBlockz;
        }

        protected void ex(KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
                this.Close();
            else if (e.Key == Key.Return)
            {
                //Todo copy key
            }
        }

        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);
            var hwnd = new System.Windows.Interop.WindowInteropHelper(this).Handle;
            SetWindowLong(hwnd, GWL_EXSTYLE, GetWindowLong(hwnd, GWL_EXSTYLE) | WS_EX_TRANSPARENT | WS_EX_LAYERED);

            // Set the position and size of the window
            this.Left = 100;
            this.Top = 100;
            this.Width = 300;
            this.Height = 100;
        }

        private const int GWL_EXSTYLE = -20;
        private const int WS_EX_TRANSPARENT = 0x20;
        private const int WS_EX_LAYERED = 0x80000;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int GetWindowLong(IntPtr hwnd, int index);

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SetWindowLong(IntPtr hwnd, int index, int newStyle);
    }
}
