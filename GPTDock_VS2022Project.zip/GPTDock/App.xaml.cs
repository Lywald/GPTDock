﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace GPTDock
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
