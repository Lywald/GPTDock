﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Runtime.InteropServices;
using System.Drawing;
using OpenAI_API;
using System.Windows.Forms;

namespace GPTDock
{
    /// <summary>
    /// Interaction logic for ModalDialogVision.xaml
    /// </summary>
    
    public partial class ModalDialogVision : Window
    {
        OpenAIAPI api = new OpenAIAPI(Properties.Settings.Default.OpenAIAPIKey); // shorthand

        public ModalDialogVision()
        {
            InitializeComponent();

            this.KeyDown += (s, e) => ex(e);
            this.Topmost = true;
            txtMessage.Focus();
        }

        private void ex(System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == Key.Return && !Keyboard.IsKeyDown(Key.LeftShift))
            {
                RoutedEventArgs clickEvent = new RoutedEventArgs(System.Windows.Controls.Button.ClickEvent);

                runButt.RaiseEvent(clickEvent);
            } else if (e.Key == Key.Escape)
            {
                this.Close();
            }
        }

        private void Button_RunClick(object sender, RoutedEventArgs e)
        {
            GPTVizz(txtMessage.Text);

            
        }
        private void cancelButt_Click(object sender, RoutedEventArgs e)
        {
            //GPTVizz(txtMessage.Text);
            this.Close();

        }
        
        private async void GPTVizz(string text)
        {
            this.runButt.IsEnabled = false;
            this.txtMessage.IsEnabled = false;

            saveScreenshot();
            var result = await api.Chat.CreateChatCompletionAsync(text, OpenAI_API.Chat.ChatMessage.ImageInput.FromFile("myScreenshot.jpg"));
            var ov = new OverlayWindow(result.Choices[0].Message.Content);
            ov.Owner = this; // Set the owner of the modal window to the main window
            //ov.MinWidth= 1200; // Set the width of the modal window
            //ov.MinHeight = 600; // Set the height of the modal window
            //ov.Width = 180;
            //ov.Height = 300;
            
            ov.ShowDialog();
            this.runButt.IsEnabled = true;
            this.txtMessage.IsEnabled = true;
        }

        private void saveScreenshot()
        {
            Bitmap captureBitmap = new Bitmap(1024, 768, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
            System.Drawing.Rectangle captureRectangle = Screen.AllScreens[0].Bounds;

            using (Graphics captureGraphics = Graphics.FromImage(captureBitmap))
            {
                captureGraphics.CopyFromScreen(captureRectangle.Left, captureRectangle.Top, 0, 0, captureRectangle.Size);
                // Save the captured screenshot
                captureBitmap.Save("myScreenshot.jpg", ImageFormat.Jpeg);
            }
        }
    }
}
