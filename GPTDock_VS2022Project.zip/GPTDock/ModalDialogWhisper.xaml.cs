﻿using NAudio.Wave;
using OpenAI_API;
using OpenAI_API.Moderation;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GPTDock
{
    /// <summary>
    /// Interaction logic for ModalDialogWhisper.xaml
    /// </summary>
    public partial class ModalDialogWhisper : Window
    {
        OpenAIAPI api = new OpenAIAPI(Properties.Settings.Default.OpenAIAPIKey); // shorthand

        //NAudio.Wave.WaveInEvent waveIn;
        public WaveIn waveSource = null;
        public WaveFileWriter waveFile = null;
        private bool isClosing = false;

        public ModalDialogWhisper()
        {
            InitializeComponent();
            this.Topmost = true;

            this.KeyDown += (s, e) => ex(e);

            ///////////////////////////
            ///
            /*
            waveIn = new NAudio.Wave.WaveInEvent
            {
                DeviceNumber = 0, // indicates which microphone to use
                WaveFormat = new NAudio.Wave.WaveFormat(rate: 44100, bits: 16, channels: 1),
                BufferMilliseconds = 20
            };
            waveIn.DataAvailable += WaveIn_DataAvailable;
            waveIn.StartRecording();*/
            ///////////////////////////
            waveSource = new WaveIn();
            waveSource.WaveFormat = new WaveFormat(44100, 1);
            waveSource.DataAvailable += new EventHandler<WaveInEventArgs>(waveSource_DataAvailable);
            waveSource.RecordingStopped += new EventHandler<StoppedEventArgs>(waveSource_RecordingStopped);
            waveFile = new WaveFileWriter(@"Test0001.wav", waveSource.WaveFormat);
            waveSource.StartRecording();
            /*
            Console.WriteLine("C# Audio Level Meter");
            for (int i = -1; i < NAudio.Wave.WaveIn.DeviceCount; i++)
            {
                var caps = NAudio.Wave.WaveIn.GetCapabilities(i);
                txtMessage.AppendText($"{i}: {caps.ProductName}");
            }*/
        }

        private void ex(KeyEventArgs e)
        {
            if (e.Key == Key.Return || e.Key == Key.Enter)
            {
                Button_RunClick(this, new RoutedEventArgs());
            }
            else if (e.Key == Key.Escape) {
                this.Close();
            }
        }

        private void Button_RunClick(object sender, RoutedEventArgs e)
        {
            whisperLabel.Content = "PROCESSING...";
            //waveIn.StopRecording();
            if (waveSource != null)
                waveSource.StopRecording();
            
            this.runButt.IsEnabled = false;
            //this.txtMessage.IsEnabled = false;

            //GPTWhizz(txtMessage.Text);
        }

        private async void GPTWhizz(string text)
        {
            string resultText = await api.Transcriptions.GetTextAsync("Test0001.wav", Properties.Settings.Default.TranscriptionLanguage, text);
            var chat = api.Chat.CreateConversation();
            chat.AppendUserInput(resultText);
            string gptText = await chat.GetResponseFromChatbotAsync(); 
            var ov = new OverlayWindow("\n" + resultText + "\n\nGPT Reply: \n\n" + gptText + "\n\n");
            ov.Owner = this; // Set the owner of the modal window to the main window
                             //ov.MinWidth= 1200; // Set the width of the modal window
                             //ov.MinHeight = 600; // Set the height of the modal window
                             //ov.Width = 180;
                             //ov.Height = 300;

            ov.ShowDialog();
            this.Close();
            this.runButt.IsEnabled = true;
            //this.txtMessage.IsEnabled = true;
        }

        void waveSource_DataAvailable(object sender, WaveInEventArgs e)
        {
            if (waveFile != null)
            {
                waveFile.Write(e.Buffer, 0, e.BytesRecorded);
                waveFile.Flush();
            }
        }

        void waveSource_RecordingStopped(object sender, StoppedEventArgs e)
        {
            if (isClosing) return;

            if (waveSource != null)
            {
                waveSource.Dispose();
                waveSource = null;
            }

            if (waveFile != null)
            {
                //waveFile.EndWrite(null);
                waveFile.Dispose();
                waveFile = null;
            }


            GPTWhizz("");// txtMessage.Text);
            //StartBtn.Enabled = true;
        }

        static void WaveIn_DataAvailable(object? sender, NAudio.Wave.WaveInEventArgs e)
        {
            // copy buffer into an array of integers
            Int16[] values = new Int16[e.Buffer.Length / 2];
            Buffer.BlockCopy(e.Buffer, 0, values, 0, e.Buffer.Length);

            // determine the highest value as a fraction of the maximum possible value
            float fraction = (float)values.Max() / 32768;

            // print a level meter using the console
            string bar = new('#', (int)(fraction * 70));
            string meter = "[" + bar.PadRight(60, '-') + "]";
        }

        private void cancelButt_Click(object sender, RoutedEventArgs e)
        {
            //GPTVizz(txtMessage.Text);
            isClosing = true;
            if (waveSource != null)
                waveSource.StopRecording();
            this.Close();

        }
    }
}
