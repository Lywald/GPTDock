﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GPTDock
{
    /// <summary>
    /// Interaction logic for SettingsWindow.xaml
    /// </summary>
    public partial class SettingsWindow : Window
    {
        public SettingsWindow(MainWindow owning)
        {
            InitializeComponent();

            TB_OpenAIAPIKey.Text = Properties.Settings.Default.OpenAIAPIKey;
            TB_UIWidth.Text = Properties.Settings.Default.UIWidth.ToString();
            TB_Lang.Text = Properties.Settings.Default.TranscriptionLanguage;

            this.PreviewKeyDown += new System.Windows.Input.KeyEventHandler(kkk);

            var desktopWorkingArea = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea;

            if (Properties.Settings.Default.LeftPos == 222 || Properties.Settings.Default.LeftPos > desktopWorkingArea.Right
                || Properties.Settings.Default.LeftPos < 0 || Properties.Settings.Default.TopPos > desktopWorkingArea.Bottom
                || Properties.Settings.Default.TopPos < 0)
            {
                Properties.Settings.Default.LeftPos = (int)(desktopWorkingArea.Right - this.Width - 100);
                Properties.Settings.Default.TopPos = (int)(desktopWorkingArea.Bottom - this.Height - 100);
            }

            TB_Left.Text = Properties.Settings.Default.LeftPos.ToString();
            TB_Top.Text = Properties.Settings.Default.TopPos.ToString();

            owning.Left = Properties.Settings.Default.LeftPos;
            owning.Top = Properties.Settings.Default.TopPos;
            //this.KeyDown += (
        }

        private void kkk(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
                this.Close();
        }

        private void TB_OpenAIAPIKey_Changed(object sender, TextChangedEventArgs e)
        {
            Properties.Settings.Default.OpenAIAPIKey = TB_OpenAIAPIKey.Text;
            Properties.Settings.Default.Save();
        }

        private void TB_UIWidth_Changed(object sender, TextChangedEventArgs e)
        {
            Properties.Settings.Default.UIWidth = int.Parse(TB_UIWidth.Text);
            Properties.Settings.Default.Save();

        }

        private void TB_Lang_Changed(object sender, TextChangedEventArgs e)
        {
            Properties.Settings.Default.TranscriptionLanguage = TB_Lang.Text;
            Properties.Settings.Default.Save();

        }

        private void TB_Left_Changed(object sender, TextChangedEventArgs e)
        {
            var fmt = new NumberFormatInfo();
            fmt.NegativeSign = "−";
            Properties.Settings.Default.LeftPos = (int)(float.Parse(TB_Left.Text, fmt));
            Properties.Settings.Default.Save();

        }

        private void TB_Top_Changed(object sender, TextChangedEventArgs e)
        {
            var fmt = new NumberFormatInfo();
            fmt.NegativeSign = "−";
            Properties.Settings.Default.TopPos = (int)float.Parse(TB_Top.Text, fmt);
            Properties.Settings.Default.Save();

        }

        private void saveButt_Click(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.Save();
            (Owner as MainWindow).Vb.Width = Properties.Settings.Default.UIWidth;
            (Owner as MainWindow).Left = Properties.Settings.Default.LeftPos;
            (Owner as MainWindow).Top = Properties.Settings.Default.TopPos;
        }

        private void TB_OpenAIAPIKey_Key(object sender, KeyEventArgs e)
        {

        }
    }
}
