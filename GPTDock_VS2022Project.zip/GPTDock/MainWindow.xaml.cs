﻿using System.Diagnostics;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GPTDock
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.Topmost = true; // Makes the window always on top
            var desktopWorkingArea = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea;
            //this.Left = desktopWorkingArea.Right - this.Width - 100;
            //this.Top = desktopWorkingArea.Bottom - this.Height - 100;
            this.Left = Properties.Settings.Default.LeftPos;
            this.Top = Properties.Settings.Default.TopPos;
            if (this.Left < 0) this.Left = 0;
            if (this.Top < 0) this.Top = 0;
            if (this.Left > desktopWorkingArea.Right) this.Left = 0;
            if (this.Top > desktopWorkingArea.Bottom) this.Top = 0;
            this.WindowStyle = WindowStyle.None; // No borders etc.
            this.AllowsTransparency = true; // Allows the window to be transparent
            this.Background = Brushes.Transparent; // Transparent background
            this.Vb.Width = Properties.Settings.Default.UIWidth;
            Application.Current.MainWindow.Icon = new BitmapImage(new Uri("pack://application:,,,/Resources/gptdock.png"));

            //moveIcon.MouseDown += MoveIcon_MouseDown;
            //moveIcon.MouseMove += MoveIcon_MouseMove;
            //moveIcon.MouseUp += MoveIcon_MouseUp;
        }


        

        private void Button_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            // Prevent the event from bubbling up to avoid default context menu
            e.Handled = true;

            // Specify the URL you want to open
            string url = "http://chat.openai.com";

            // Start the default browser with the URL
            //System.Diagnostics.Process.Start(url);
            var psi = new ProcessStartInfo
            {
                FileName = url,
                UseShellExecute = true
            };
            Process.Start(psi);
        }

        private void Button2_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            // Prevent the event from bubbling up to avoid default context menu
            e.Handled = true;

            // Specify the URL you want to open
            string url = "http://perplexity.ai";

            // Start the default browser with the URL
            //System.Diagnostics.Process.Start(url);
            var psi = new ProcessStartInfo
            {
                FileName = url,
                UseShellExecute = true
            };
            Process.Start(psi);
        }

        private void btnGptVision_Click(object sender, RoutedEventArgs e)
        {
            // Add your logic for GPT Vision here
            //MessageBox.Show("GPT Vision button clicked.");
            var ModalDialogVision = new ModalDialogVision();
            var desktopWorkingArea = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea;
            ModalDialogVision.Left = desktopWorkingArea.Right - this.Width - 55;
            ModalDialogVision.Top = desktopWorkingArea.Bottom - 500;
            ModalDialogVision.ShowDialog();
        }

        private void btnGptWhisper_Click(object sender, RoutedEventArgs e)
        {
            // Add your logic for GPT Whisper here
            var ModalDialogWhisper = new ModalDialogWhisper();
            var desktopWorkingArea = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea;
            ModalDialogWhisper.Left = desktopWorkingArea.Right - this.Width - 55;
            ModalDialogWhisper.Top = desktopWorkingArea.Bottom - 500;
            ModalDialogWhisper.ShowDialog();
        }

        private void btnTextGpt_Click(object sender, RoutedEventArgs e)
        {
            // Add your logic for Text GPT here
            //MessageBox.Show("Text GPT button clicked.");
            var ModalDialogChat = new ModalDialogChat();
            var desktopWorkingArea = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea;
            ModalDialogChat.Left = desktopWorkingArea.Right - this.Width - 350;
            ModalDialogChat.Top = desktopWorkingArea.Top + 100;

            ModalDialogChat.ShowDialog();
        }

        private void closeImg_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }

        private void settImg_MouseDown(object sender, MouseButtonEventArgs e)
        {
            var settingsWindow = new SettingsWindow(this);
            var desktopWorkingArea = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea;
            
            settingsWindow.Left = desktopWorkingArea.Right - this.Width - 205;
            settingsWindow.Top = desktopWorkingArea.Bottom - 500;
            settingsWindow.Owner = this;
            settingsWindow.ShowDialog();
        }
    }
}