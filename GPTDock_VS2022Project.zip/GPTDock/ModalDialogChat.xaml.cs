﻿using OpenAI_API;
using OpenAI_API.Chat;
using OpenAI_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GPTDock
{
    /// <summary>
    /// Interaction logic for ModalDialogChat.xaml
    /// </summary>
    public partial class ModalDialogChat : Window
    {
        OpenAIAPI api = new OpenAIAPI(Properties.Settings.Default.OpenAIAPIKey); // shorthand
        Conversation chat;

        public ModalDialogChat()
        {
            InitializeComponent();
            this.Topmost = true;
            this.PreviewKeyDown += new System.Windows.Input.KeyEventHandler(richInput_KeyDown);

            chat = api.Chat.CreateConversation();
            chat.Model = Model.GPT4_Turbo;

            richInput.Focus();
        }

        private async void richInput_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if ((e.Key == Key.Return || e.Key == Key.Enter) && !Keyboard.IsKeyDown(Key.LeftShift))
            {
                e.Handled = true; // This prevents the RichTextBox from processing the Enter key (inserting a new line).

                // Disable input to prevent multiple requests
                richInput.IsEnabled = false;

                TextRange textRange = new TextRange(
                    richInput.Document.ContentStart,
                    richInput.Document.ContentEnd
                );

                string richText = textRange.Text;

                //richInput.cle
                richInput.Document.Blocks.Clear();

                chat.AppendUserInput(richText);

                //richOutput.AppendText("\n<b>" + richText + "</b>\n");
                Paragraph newParagraph = new Paragraph();
                Run run = new Run(richText);
                Bold bold = new Bold(run);
                newParagraph.Inlines.Add(bold);
                richOutput.Document.Blocks.Add(newParagraph);
                richOutput.ScrollToEnd();

                Paragraph newParagraphGPT = new Paragraph();
                richOutput.Document.Blocks.Add(newParagraphGPT);

                try
                {
                    await foreach (var res in chat.StreamResponseEnumerableFromChatbotAsync())
                    {
                        // Update the UI on the UI thread
                        Dispatcher.Invoke(() =>
                        {
                            //   richOutput.AppendText(res);
                            Run gptRun = new Run(res);
                            newParagraphGPT.Inlines.Add(gptRun);
                            richOutput.ScrollToEnd();
                        });
                    }
                }
                catch (Exception ex)
                {
                    // Handle any exceptions that may occur
                    Dispatcher.Invoke(() =>
                    {
                        //richOutput.AppendText("Error: " + ex.Message);
                        // Handle any exceptions that might occur during the async operation
                        Run errorRun = new Run("Error: " + ex.Message);
                        newParagraphGPT.Inlines.Add(errorRun);
                        richOutput.ScrollToEnd();
                    });
                }
                finally
                {
                    // Re-enable input
                    Dispatcher.Invoke(() => richInput.IsEnabled = true);
                }

                richOutput.AppendText("\n\n");
            }
            else if (e.Key == Key.Escape)
            {
                // Ensure the window close command is run on the UI thread
                Dispatcher.Invoke(() => this.Close());
            }
        }



    }
}
